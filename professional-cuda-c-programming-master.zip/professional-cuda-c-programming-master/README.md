Professional CUDA C Programming
===============================

Included here are the code files for any samples used in the chapters as
illustrative examples.

Each chapter has its own code folder that includes the sample .c and .cu files
for that chapter. The per-chapter folders each also include a Makefile that can
be used to build the samples included.

The common/ directory contains common.h, which includes code that is common to
multiple chapters.
